# r3nana
## Home: http://r3mina.herokuapp.com
## Anime: https://anilist.co/search/anime
## Feature
- [x] View from https://anilist.co watch
- [ ] Merge id and name
